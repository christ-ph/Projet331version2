# def info_comm(mots_cle):
mots_cle = list(input("entre les mots que vous voulez retrouve dans les commantaires et une vigurle pour leur separe").split(','))

for p in mots_cle:
     print(p)

